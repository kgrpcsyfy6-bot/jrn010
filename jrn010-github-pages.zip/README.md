# JRN010 — Renfugan

最新课堂演示网页：三页英文内容，采用 Apple 官网风格的视觉设计，保留概念点击与方向键翻页。无需安装或构建。

## 部署到 GitHub Pages

1. 解压部署包，将 `index.html`、`.nojekyll` 和 `README.md` 上传到 `kgrpcsyfy6-bot/jrn010` 仓库的 `main` 分支根目录。不要把 ZIP 或外层文件夹直接上传。
2. 如果仓库里已有同名文件，替换它们，然后提交更改。
3. 在仓库的 **Settings → Pages → Build and deployment** 中，选择：
   - Source：**Deploy from a branch**
   - Branch：**main**
   - Folder：**/ (root)**
4. 点击 **Save**，等 Pages 部署完成。
5. 打开：https://kgrpcsyfy6-bot.github.io/jrn010/

仓库：https://github.com/kgrpcsyfy6-bot/jrn010
Pages 设置：https://github.com/kgrpcsyfy6-bot/jrn010/settings/pages

GitHub Pages 部署完成之前，上述网页地址可能无法打开。也可以在电脑上直接打开 `index.html` 预览。
